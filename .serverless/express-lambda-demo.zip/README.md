Demo from https://serverless.com/blog/serverless-express-rest-api/
